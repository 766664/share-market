# SHARE MARKET – KIRAN CHAURE

Starter Android app for the Share Market project.

Package: `com.kiranchaure.sharemarket`

This starter includes:
- Home screen
- Chart placeholder
- 5-minute early-alert framework
- Order Block and Liquidity settings
- Automatic Order switch (default OFF)
- SmartAPI callback deep-link placeholder

The signal examples in this starter are demo UI only, not live market predictions.
