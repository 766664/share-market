package com.kiranchaure.sharemarket

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Signal(val name: String, val signal: String, val reason: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShareMarketApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShareMarketApp() {
    var tab by remember { mutableStateOf(0) }
    Scaffold(
        topBar = {
            TopAppBar(title = {
                Column {
                    Text("SHARE MARKET")
                    Text("KIRAN CHAURE", style = MaterialTheme.typography.labelSmall)
                }
            })
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, icon = { Text("⌂") }, label = { Text("Home") })
                NavigationBarItem(tab == 1, { tab = 1 }, icon = { Text("▥") }, label = { Text("Chart") })
                NavigationBarItem(tab == 2, { tab = 2 }, icon = { Text("⚙") }, label = { Text("Settings") })
            }
        }
    ) { p ->
        when (tab) {
            0 -> HomeScreen(Modifier.padding(p))
            1 -> ChartScreen(Modifier.padding(p))
            else -> SettingsScreen(Modifier.padding(p))
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier) {
    val signals = listOf(
        Signal("SENSEX", "WAIT", "Trend confirmation ka wait"),
        Signal("NIFTY", "EARLY BUY", "Demo: bullish conditions"),
        Signal("BANK NIFTY", "EARLY SELL", "Demo: bearish conditions")
    )
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Market Analysis", style = MaterialTheme.typography.headlineSmall) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("5-Minute Early Trend Alert", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Trend change ke possible signs par early warning ka framework.")
                }
            }
        }
        items(signals) { s ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(s.name, style = MaterialTheme.typography.titleLarge)
                    Text(s.signal, style = MaterialTheme.typography.titleMedium)
                    Text("Reason: ${s.reason}")
                }
            }
        }
    }
}

@Composable
fun ChartScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Live Market Chart", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(20.dp))
        Card(Modifier.fillMaxWidth().height(300.dp)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("LIVE CHART\n\nAngel One SmartAPI data yahan aayega")
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Timeframe: 1m | 5m | 10m | 15m")
    }
}

@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    var early by remember { mutableStateOf(true) }
    var orderBlock by remember { mutableStateOf(true) }
    var liquidity by remember { mutableStateOf(true) }
    var autoOrder by remember { mutableStateOf(false) }

    LazyColumn(modifier.fillMaxSize().padding(16.dp)) {
        item { Text("Settings", style = MaterialTheme.typography.headlineSmall); Spacer(Modifier.height(12.dp)) }
        item { Setting("5-Minute Early Alert", early) { early = it } }
        item { Setting("Order Block", orderBlock) { orderBlock = it } }
        item { Setting("Liquidity Detection", liquidity) { liquidity = it } }
        item { Setting("Automatic Order", autoOrder) { autoOrder = it } }
        item { Text("Automatic Order default: OFF", modifier = Modifier.padding(top = 12.dp)) }
    }
}

@Composable
fun Setting(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        Switch(checked, onChange)
    }
}
